package com.skillswaphub.model;

public enum RoleName {
    ROLE_USER,
    ROLE_ADMIN
}
